$wnd.vks_vpn_DefaultWidgetset.runAsyncCallback2('yhb(1610,1,R1d);_.Wd=function Wic(){O3b((!H3b&&(H3b=new T3b),H3b),this.a.d)};RWd(Cl)(2);\n//# sourceURL=vks.vpn.DefaultWidgetset-2.js\n')
